export interface CategoryModel {
  readonly id: number;
  readonly title: string;
  readonly category: string;
}
