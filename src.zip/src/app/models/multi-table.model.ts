export interface MultiTableModel {
  readonly title: string;
  readonly category: string;
  readonly price: string;
  readonly image: string;
}
