export interface TableNamesModel {
  readonly name: string;
  readonly lp: string;
}
