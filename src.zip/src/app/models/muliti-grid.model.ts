export interface MulitiGridModel {
  readonly title: string;
  readonly description: string;
  readonly tag: string;
}
