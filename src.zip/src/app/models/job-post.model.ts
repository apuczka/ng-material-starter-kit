export interface JobPostModel {
  readonly title: string;
  readonly description: string;
  readonly tags: string;
  readonly name: string;
}
