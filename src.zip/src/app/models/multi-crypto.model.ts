export interface MultiCryptoModel {
  readonly symbol: string;
  readonly price: string;
  readonly quantity: string;
}
