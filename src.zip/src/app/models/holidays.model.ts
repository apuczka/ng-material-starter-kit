export interface HolidaysModel {
  readonly date: string;
  readonly name: string;
}
