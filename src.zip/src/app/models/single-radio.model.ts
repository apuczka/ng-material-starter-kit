export interface SingleRadioModel {
  readonly id: string;
  readonly title: string;
  readonly symbol: Text;
}
