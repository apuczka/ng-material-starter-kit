import { NgModule } from '@angular/core';
import { ProductComponent } from './product.component';

@NgModule({
  imports: [],
  declarations: [ProductComponent],
  providers: [],
  exports: [ProductComponent]
})
export class ProductComponentModule {
}
