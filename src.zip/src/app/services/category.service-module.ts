import { NgModule } from '@angular/core';
import { CategoryService } from './category.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [CategoryService],
  exports: []
})
export class CategoryServiceModule {
}
